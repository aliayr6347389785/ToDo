package com.uli.todo.ui.fragment.notifications

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.uli.todo.base.BaseFragment
import com.uli.todo.databinding.FragmentAddNoteBinding
import com.uli.todo.databinding.FragmentNotificationsBinding

class NotificationsFragment :
    BaseFragment<FragmentNotificationsBinding>(FragmentNotificationsBinding::inflate) {
    override fun setupUI() {
        TODO("Not yet implemented")
    }

    override fun setupObserver() {
        super.setupObserver()
    }

}