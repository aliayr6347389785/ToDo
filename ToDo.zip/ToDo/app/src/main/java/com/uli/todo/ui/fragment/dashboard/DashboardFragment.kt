package com.uli.todo.ui.fragment.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.uli.todo.base.BaseFragment
import com.uli.todo.databinding.FragmentDashboardBinding

class DashboardFragment :
    BaseFragment<FragmentDashboardBinding>(FragmentDashboardBinding::inflate) {
    override fun setupUI() {
        TODO("Not yet implemented")
    }

    override fun setupObserver() {
        super.setupObserver()
    }
}