package com.uli.todo.data.model

data class NoteModel(
    val title: String? = null,
    val description: String? = null
)
