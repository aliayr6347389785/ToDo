package com.uli.todo.ui.fragment.home

import com.uli.todo.base.BaseFragment
import com.uli.todo.databinding.FragmentHomeBinding

class HomeFragment
    : BaseFragment<FragmentHomeBinding>(FragmentHomeBinding::inflate) {

    override fun setupUI() {
        TODO("Not yet implemented")
    }

    override fun setupObserver() {
        super.setupObserver()
    }
}