package com.uli.todo.ui.fragment.addNote

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.uli.todo.R
import com.uli.todo.base.BaseFragment
import com.uli.todo.databinding.FragmentAddNoteBinding

class AddNoteFragment :
    BaseFragment<FragmentAddNoteBinding>(FragmentAddNoteBinding::inflate) {
    override fun setupUI() {
        TODO("Not yet implemented")
    }

    override fun setupObserver() {
        super.setupObserver()
    }
}